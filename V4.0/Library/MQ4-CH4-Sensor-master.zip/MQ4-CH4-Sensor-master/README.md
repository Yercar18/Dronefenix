# MQ4 Library

MQ4 es un proyecto de codigo abierto. Es una extension
de AirQ,  el objetivo es realizar una libreria donde con 
el sensor MQ4 se pueda determinar:

  1. Las concentraciones de gas metano en el aire.
  2. Las concentraciones de alcohol en el aire.

Esta libreria se ha creado basado en el siguiente
video (ingles):
https://www.youtube.com/watch?v=fBo3Yq9LK1U&t=79s

License
----

MIT

Contact
----
Miguel Angel Califa Urquiza
miguelangel5612@gmail.com

